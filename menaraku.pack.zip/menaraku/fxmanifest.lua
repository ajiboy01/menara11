fx_version 'cerulean'
games { 'gta5' }
lua54 'yes'

authors { 'ANTULILIN' }
description 'KL Tower 2024'
version '2.0 Early Access'
url 'https://www.iconmy.com.my/gta5/mods/114'


data_file 'DLC_ITYP_REQUEST' 'stream/menaraku.ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/tapakkl.ytyp'

files 
{
'stream/menaraku.ytyp',
'stream/menaraku.ydr',
'stream/menaraku.ymap',
'stream/hei_hw1_rd.ymap',
'stream/hei_hw1_rd_critical_0.ymap',
'stream/menaraku_texture.ytd',
'stream/tapakkl.ytyp',
'stream/tapakkl.ydr',
'stream/tapakkl_texture.ytd',
}

this_is_a_map 'yes'
dependency '/assetpacks'