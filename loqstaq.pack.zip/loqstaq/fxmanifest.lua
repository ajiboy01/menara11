fx_version 'cerulean'
games { 'gta5' }
lua54 'yes'

authors { 'ANTULILIN' }
description 'Menara TM Alor Star 2024'
version '1.0 Early Access'
url 'https://www.iconmy.com.my/gta5/mods/116'

this_is_a_map 'yes'

data_file 'DLC_ITYP_REQUEST' 'stream/loqstaq.ytyp'

files 
{
'stream/loqstaq.ytyp',
'stream/loqstaq.ydr',
'stream/loqstaq.ymap',
'stream/loqstaq_texture.ytd',
}
dependency '/assetpacks'